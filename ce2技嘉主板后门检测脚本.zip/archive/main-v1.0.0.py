

import os
import sys
import importlib
import time
from datetime import datetime
import requests
import hashlib
from zipfile import ZipFile
import argparse

importlib.reload(sys)

_today_ = datetime.today().strftime('%Y-%m-%d')
_ctime_ = datetime.today().strftime('%Y-%m-%d %H:%M:%S')

_home_path_ = '%s' % os.getcwd()

_engine_zipfile_ = '%s/%s.zip' % (_home_path_, _today_)
_engine_extract_file_ = '%s/engine.db' % _home_path_

_scan_result_logs_ = '%s/output/%s-infected.log' % (_home_path_, _today_)
_scan_extension_list_ = ['.exe', '.dll', '.sys', '.doc', '.docx', '.xls', '.xlsx', '.py', '.xml', '.cfg', '.txt','.ppt', '.pptx', '.hwp']


class Bcolors:
    Black = '\033[30m'
    Red = '\033[31m'
    Green = '\033[32m'
    Yellow = '\033[33m'
    Blue = '\033[34m'
    Magenta = '\033[35m'
    Cyan = '\033[36m'
    White = '\033[37m'
    Endc = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'


def download_engine():
    _url = 'https://bazaar.abuse.ch/export/txt/sha256/full/'
    _header = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_4) AppleWebKit/537.36 (KHTML, like Gecko) '
                             'Chrome/49.0.2623.112 Safari/537.36', 'Connection': 'keep-alive'}
    try:
        with open(_engine_zipfile_, 'wb') as f:   
            r = requests.get(_url, headers=_header, stream=True)
            download_file_length = r.headers.get('Content-Length')
            print('%s Downloading: %s / %.2f MB %s'
                  % (Bcolors.Green, _engine_zipfile_, (float(download_file_length) / (1024.0 * 1024.0)), Bcolors.Endc))

            if download_file_length is None:
                f.write(r.content)
            else:
                dl = 0
                total_length = int(download_file_length)
                start = time.perf_counter()
                for data in r.iter_content(chunk_size=8092):
                    dl += len(data)
                    f.write(data)
                    done = int(100 * dl / total_length)
                    sys.stdout.write('\r [%s%s] %s/%s (%s%%) - %.2f seconds '
                                     % ('>' * done, ' ' * (100 - done), total_length, dl,
                                        done, (time.perf_counter() - start)))
                    sys.stdout.flush()
        f.close()

        extract_gzip(_engine_zipfile_, _home_path_)

    except Exception as e:
        print('%s[-] Exception::%s%s' % (Bcolors.Yellow, e, Bcolors.Endc))
    else:
        r.close()


def extract_gzip(_engine_zipfile_, _home_path_):
    with ZipFile(_engine_zipfile_, 'r') as zipObj:
        file_list = zipObj.infolist()
        for file in file_list:
            if file.filename[-1] == '/':
                continue
            file.filename = os.path.basename(file.filename)
            if file.filename.lower() == 'full_sha256.txt'.lower():
                zipObj.extract(file, _home_path_)
                _update_file = '%s/%s' % (_home_path_, file.filename)
                try:
                    os.rename(_update_file, _engine_extract_file_)
                except OSError as e:
                    print('%s can not be renamed' % _update_file)
                    print('%s- Exception::%s%s' % (Bcolors.Yellow, e, Bcolors.Endc))
                    sys.exit(1)

    # Remove Engine zip
    try:
        os.remove(_engine_zipfile_)
    except OSError as e:
        print('%s can not be removed' % _engine_zipfile_)
        print('%s- Exception::%s%s' % (Bcolors.Yellow, e, Bcolors.Endc))
        sys.exit(1)

    # Check Downloaded File
    if os.path.isfile(_engine_extract_file_):
        f = open(_engine_extract_file_, 'rb')
        file_read = f.read()
        f.close()

        file_hash = hashlib.sha256(file_read).hexdigest()
        file_info = '===> Extracted Size: %.2f MB\n===> Hash(SHA-256) : %s\n' \
                    % (int(os.path.getsize(_engine_extract_file_)) / (1024.0 * 1024.0), file_hash)

        print('\n\n%s===> Update Success: %s %s' % (Bcolors.Green, _engine_extract_file_, Bcolors.Endc))
        print('%s%s%s' % (Bcolors.Green, file_info, Bcolors.Endc))
    else:
        print('%s[-] %s not found. %s' % (Bcolors.Yellow, _engine_extract_file_, Bcolors.Endc))
        sys.exit(1)


def raw_count(filename):
    _n = 0
    with open(filename) as f:
        for line in f:
            if not line.startswith('#'):
                _n = _n + 1
    f.close()
    return n


def engine_last_dated(filename):
    with open(filename) as f:
        for line in f:
            if 'Last updated' in line:
                line = line.replace('#', '')
                line = line.lstrip().strip('\n')
                line = line.split(' ')
                line = line[2:5]
                line = ' '.join(line)
                break
    f.close()
    return line


def hash_exists_in_db(check_hash):
    _mode = 'r'
    _n = 0
    with open(_engine_extract_file_, _mode) as database:
        for line in database:
            _n = _n + 1
            if len(line.strip()) != 0:
                if not line.startswith('#'):
                    if str(check_hash) in str(line):
                        return True
    return False


def scan_result_logs(_contents):
    _make_output_dir = '%s/output' % _home_path_
    _mode = 'w'

    if os.path.exists(_make_output_dir):
        if os.path.exists(_scan_result_logs_):
            _mode = 'a'
    else:
        _mode = 'w'
        os.makedirs(_make_output_dir)

    with open(_scan_result_logs_, _mode) as fa:
        fa.write('%s' % _contents)
    fa.close()


def make_hash(_file_name):
    _file_hash = ''
    if os.path.isfile(_file_name):
        f = open(_file_name, 'rb')
        filename_read = f.read()
        _file_hash = hashlib.sha256(filename_read).hexdigest()
        f.close()
    return _file_hash


def check_file_extension(_file_name):
    if _file_name.endswith(tuple(_scan_extension_list_)):
        return True
    else:
        return False


def check_file_size(_file_name):
    # 5MB = '5242880'
    _limit = 5242880

    f = os.stat(_file_name).st_size
    if f <= _limit:
        return True
    else:
        return False


def check_engine():
    _name = 'MALWARE'
    _get_download = True

    if os.path.exists(_engine_extract_file_):
        create_time = os.stat(_engine_extract_file_).st_mtime
        engine_file_datetime = datetime.fromtimestamp(create_time).strftime('%Y-%m-%d')
        today = datetime.now().date()
        if str(engine_file_datetime) == str(today):
            _get_download = True
        else:
            _get_download = False
    else:
        print('- Updating %s Signatures' % _name)
        print('%s------------------------------------->%s' % (Bcolors.Yellow, Bcolors.Endc))
        download_engine()

    if not _get_download:
        print('- Updating %s Signatures' % _name)
        print('%s------------------------------------->%s' % (Bcolors.Yellow, Bcolors.Endc))
        download_engine()


def scanner(_scan_path):
    _scanned_file_count = 0
    _infected_file_count = 0
    _scandir_file_count = sum(len(files) for _, _, files in os.walk(_scan_path))
    print('- Scan Directory  : %s' % _scan_path)
    print('- Number of files : %d' % _scandir_file_count)
    print('- Scan Extensions : %s' % str(_scan_extension_list_)[1:-1])
    print('%s------------------------------------->%s\n' % (Bcolors.Yellow, Bcolors.Endc))
    print('\x1b[7;33;40m' + 'O.K Here We go.!' + '\x1b[0m')
    print('- Currently scanning...')

    start = time.perf_counter()
    _detected = ''

    for subdir, dirs, files in os.walk(_scan_path):
        for file in files:
            _scanned_file_count = _scanned_file_count + 1
            _f_name = '%s' % os.path.join(subdir, file)
            elapsed_time = time.perf_counter() - start
            if check_file_extension(file):
                if check_file_size(_f_name):
                    scan_file_hash = make_hash(_f_name)
                    if hash_exists_in_db(scan_file_hash):
                        _infected_file_count = _infected_file_count + 1
                        _contents = '%s %s %s %s\n' % (_infected_file_count, _ctime_, _f_name, scan_file_hash)
                        _detected += _contents
                        scan_result_logs(_contents)

                    sys.stdout.write('\r- %d files scanned / %d infected [%s] (%s) '
                                     % (_scanned_file_count, _infected_file_count,
                                        datetime.strftime(datetime.utcfromtimestamp(elapsed_time), '%H:%M:%S'),
                                        _f_name))
                    #time.sleep(0.01)
                    sys.stdout.flush()

    if _infected_file_count >= 1:
        _vt_info = '\n##### For more information about infected file, search the Virustotal ###\n' \
                   'https://www.virustotal.com/gui/file/$infected_file_hash\n\n'
        scan_result_logs(_vt_info)

    print('\n')
    print('- Result')

    if _detected:
        print('%s------O------M------G--------------->-%s' % (Bcolors.Red, Bcolors.Endc))
        print('- Scanner Found %s%d%s infected files!' % (Bcolors.Yellow, _infected_file_count, Bcolors.Endc))
        print('- See the %s%s%s \n' % (Bcolors.Cyan, _scan_result_logs_, Bcolors.Endc))
    else:
        print('%s- OK.Good. No infection found.%s' % (Bcolors.Green, Bcolors.Endc))


def main():
    print('\n')
    print('%s▌║█║▌│║▌│║▌║▌█║ %sSimple Basic Malware Scanner%s▌│║▌║▌│║║▌█║▌║█%s\n'
          % (Bcolors.Green, Bcolors.Red, Bcolors.Green, Bcolors.Endc))
    opt = argparse.ArgumentParser(description='Simple Basic Malware Scanner')
    opt.add_argument('--path', help='ex) /var/www/html/upload')
    opt.add_argument('--update', action='store_true', help='AV Engine Update')

    if len(sys.argv) < 1:
        opt.print_help()
        sys.exit(1)
    else:
        options = opt.parse_args()

        if options.path:
            _scan_path = os.path.abspath(options.path)
            print('- Run time: %s' % _ctime_)
            print('- For questions contact github.com/password123456\t\t')
            print('%s------------------------------------->%s\n' % (Bcolors.Green, Bcolors.Endc))
            check_engine()            
            print('- Engine Updated  : %s' % engine_last_dated(_engine_extract_file_))
            engine_count = raw_count(_engine_extract_file_)
            print('- AV Signatures   : %s' % engine_count)
            scanner(_scan_path)

        elif options.update:
            print('- Run time: %s' % _ctime_)
            print('- For questions contact github.com/password123456\t\t')
            print('%s------------------------------------->%s\n' % (Bcolors.Green, Bcolors.Endc))
            check_engine()           
            print('- Engine Updated  : %s' % engine_last_dated(_engine_extract_file_))
            engine_count = raw_count(_engine_extract_file_)
            print('- AV Signatures   : %s' % engine_count)
        else:
            opt.print_help()
            sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
    except Exception as e:
        print('%s- Exception::%s%s' % (Bcolors.Yellow, e, Bcolors.Endc))
